package com.addressbook.vcardreader;

import java.util.Iterator;
import java.util.List;

import net.sourceforge.cardme.engine.VCardEngine;
import net.sourceforge.cardme.io.CompatibilityMode;
import net.sourceforge.cardme.vcard.VCard;
import net.sourceforge.cardme.vcard.features.TelephoneFeature;
import net.sourceforge.cardme.vcard.types.NameType;
import net.sourceforge.cardme.vcard.types.parameters.TelephoneParameterType;

import com.addressbook.beans.Contact;
import com.addressbook.beans.Person;

/**
 * @author Shubhashish Bhowmik
 *
 */
public final class vCardWrapper
{
   private final VCardEngine cardReader;

   /**
    * @param cardReader
    */
   public vCardWrapper()
   {
      this.cardReader = new VCardEngine(CompatibilityMode.RFC2426 );
   }
   
   /**
    * @param filename
    * @return
    * @throws Exception
    */
   //TODO :: Make this a better implementation
   public List<Contact> getAllContactsFromVCard( String filename ) throws Exception
   {
      final List<VCard> vCardList = cardReader.parseMultiple( filename );
      processVCardToContacts(vCardList);
      
      return null;
   }

   /**
    * @param vCardList
    */
   private void processVCardToContacts(List<VCard> vCardList)
   {
      for (VCard vcard : vCardList)
      {
         
         final NameType nametype = (NameType) vcard.getName( );
         // Person builder starts
         Person person = new PersonBuilder(nametype.getFamilyName() , nametype.getGivenName( ))
                         .addEmailAddress( vcard.getEmails( ) )
                         .addNickname( vcard.getNicknames( ) )
                         .build( );
         
         
         System.out.println("Person name : "+ person.getDisplayName( ));
         // Person building ends here
         
         // start home and work address
         Iterator<TelephoneFeature> telephones = vcard.getTelephoneNumbers( );
         while(telephones.hasNext( ))
         {
            TelephoneFeature telephonefeture = telephones.next( );
            System.out.println(" \t"+ telephonefeture.getTelephone( ) );
            for(TelephoneParameterType parametertype : telephonefeture.getTelephoneParameterTypesList( ))
            {
               switch(parametertype)
               {
                  case HOME:
                  case CELL:
                      System.out.println( "vCardWrapper.processVCardToContacts(): " + parametertype.getDescription( ));
                     break;
                  case WORK:
                     System.out.println( "vCardWrapper.processVCardToContacts(): " + parametertype.getDescription( ));
                     break;
                  default:
                     System.out.println("");
                     break;
                     
               }
               
            }
           
         }
         // end: home and work address
      }
   }
   
   public static void main(String[] args) throws Exception
   {
      vCardWrapper wrapper = new vCardWrapper();
      wrapper.getAllContactsFromVCard( "PIM00005.vcf" );
   }
   
}
