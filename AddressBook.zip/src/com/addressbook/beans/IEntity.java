/**
 * 
 */
package com.addressbook.beans;

import java.io.Serializable;

/**
 * @author Shubhashish Bhowmik
 *
 */
public interface IEntity extends Serializable
{

}
